package Foo;
our $VERSION = '0.7';
1
