package Bar;
our $VERSION = '0.8';
1
